PANEL RAKIB — REAL SHOP

1) Upload ALL files in this folder to your GitHub Pages repository.
2) The site already contains the Firebase project configuration found in the existing PANEL RAKIB app.
3) In Firebase Console, enable Authentication > Email/Password.
4) Firestore Database must be enabled.
5) Publish firestore.rules from this folder to Firestore Rules.
6) Admin UID already used by the app: HJhKQtLBuKcIKtQbtAhv3a9sEFQ2
7) Add Fund: Nagad 01602133359, minimum ৳100.
8) Telegram: https://t.me/+7VgdbHvGNDZiOTc1

Flow: Register/Login -> Add Fund -> submit amount + transaction ID -> admin approves -> balance increases -> customer buys package -> balance decreases -> order appears in My Orders -> admin marks completed.
